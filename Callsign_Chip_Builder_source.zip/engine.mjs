import qrFactory from './vendor/qrcode.mjs';
import {zipSync,strToU8} from './vendor/fflate.mjs';
qrFactory.stringToBytes=s=>Array.from(new TextEncoder().encode(s));
export const DEFAULTS={callsign:'N0CALL',firstName:'Sample',lastName:'Operator',address:'',phone:'',email:'',format:'text',ecc:'L',diameter:50,thickness:3.5,nozzle:0.4,colors:['#17191d','#ffffff','#f18418']};
export function payload(p){
  const name=[p.firstName,p.lastName].filter(Boolean).join(' ').trim()||p.callsign;
  const esc=s=>String(s||'').replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/;/g,'\\;').replace(/,/g,'\\,');
  if(p.format==='vcard')return ['BEGIN:VCARD','VERSION:3.0',`N:${esc(p.lastName)};${esc(p.firstName||(!p.lastName?p.callsign:''))};;;`,`FN:${esc(name)}`,...(p.phone?[`TEL:${p.phone}`]:[]),...(p.email?[`EMAIL:${p.email}`]:[]),...(p.address?[`ADR:;;${esc(p.address)};;;;`]:[]),`NOTE:${esc(p.callsign)}`,'END:VCARD'].join('\r\n')+'\r\n';
  return [name,p.address,p.phone,p.email].filter(Boolean).join('\n');
}
export function qrInfo(p){
  const text=payload(p);if(new TextEncoder().encode(text).length>700)throw Error('Contact is too long. Keep the QR payload below 700 UTF-8 bytes.');
  const q=qrFactory(0,p.ecc);q.addData(text,'Byte');q.make();
  const n=q.getModuleCount(),pitch=p.diameter*.64/(n+8);
  return {text,bytes:new TextEncoder().encode(text).length,n,version:(n-17)/4,pitch,quiet:pitch*4,field:p.diameter*.64,recommendedDiameter:Math.ceil((n+8)*p.nozzle*2/.64),matrix:Array.from({length:n},(_,r)=>Array.from({length:n},(_,c)=>q.isDark(r,c)))};
}
export function validate(input){
  const p={...DEFAULTS,...input};p.callsign=String(p.callsign).trim().toUpperCase();
  if(!/^[A-Z0-9/-]{3,12}$/.test(p.callsign))throw Error('Callsign: use 3–12 letters, digits, / or -.');
  for(const key of ['firstName','lastName','address','phone','email']){p[key]=String(p[key]||'').trim();if(/[\r\n\x00-\x1f]/.test(p[key]))throw Error('Contact fields must be single-line text.');}
  for(const [key,min,max] of [['diameter',40,90],['thickness',2.4,5],['nozzle',.2,.8]]){p[key]=Number(p[key]);if(!Number.isFinite(p[key])||p[key]<min||p[key]>max)throw Error(`${key}: allowed range ${min}–${max} mm.`);}
  if(Math.abs(p.thickness*10-Math.round(p.thickness*10))>1e-6)throw Error('Thickness must use 0.1 mm increments.');
  if(!['text','vcard'].includes(p.format)||!['L','M'].includes(p.ecc))throw Error('Unsupported QR setting.');
  if(!Array.isArray(p.colors)||p.colors.length!==3||p.colors.some(c=>!/^#[0-9a-f]{6}$/i.test(c)))throw Error('Choose three valid colours.');
  // The two QR materials must remain a dark/light pair for decoding.
  const lum=hex=>{const a=hex.slice(1).match(/../g).map(s=>parseInt(s,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return .2126*a[0]+.7152*a[1]+.0722*a[2];};
  if(lum(p.colors[1])<.65||lum(p.colors[0])>.15||(lum(p.colors[1])+.05)/(lum(p.colors[0])+.05)<7)throw Error('QR needs a dark body and a light field. Choose colours with stronger contrast.');
  return p;
}
export function makeEngine(module,font){
  const {CrossSection:C,Manifold:M}=module;
  return input=>{
    const p=validate(input),qr=qrInfo(p),pool=[];const k=o=>(pool.push(o),o);
    try{
      const poly=points=>k(new C([points],'EvenOdd'));
      const union=arr=>k(C.union(arr));const sub=(a,b)=>k(a.subtract(b));const intersect=(a,b)=>k(a.intersect(b));
      const tr=(a,x,y)=>k(a.translate([x,y]));const scale=(a,x,y=x)=>k(a.scale([x,y]));
      const disk=(r,x=0,y=0)=>tr(k(C.circle(r,128)),x,y);
      const rect=(x0,y0,x1,y1)=>tr(k(C.square([x1-x0,y1-y0])),x0,y0);
      const stroke=(points,w)=>union(points.slice(1).map((b,i)=>{const a=points[i],dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy);if(!len)return disk(w/2,...a);const nx=-dy/len*w/2,ny=dx/len*w/2;return union([poly([[a[0]+nx,a[1]+ny],[a[0]-nx,a[1]-ny],[b[0]-nx,b[1]-ny],[b[0]+nx,b[1]+ny]]),disk(w/2,...a),disk(w/2,...b)]);}));
      const circle=disk(25),ro=[],rw=[];
      for(let i=0;i<8;i++){const a=Math.PI*i/4,points=[];for(let j=0;j<=24;j++){const t=a-.16+.32*j/24;points.push([26*Math.cos(t),26*Math.sin(t)]);}for(let j=24;j>=0;j--){const t=a-.16+.32*j/24;points.push([23.55*Math.cos(t),23.55*Math.sin(t)]);}(i%2?rw:ro).push(intersect(poly(points),circle));}
      const orangeRim=union(ro),whiteRim=union(rw),ring=(r,w)=>sub(disk(r),disk(r-w));
      const radio=(x,y,s)=>{
        const mast=union([stroke([[-2.7,-4],[0,4],[2.7,-4]],.65),stroke([[0,-4],[0,4]],.55),stroke([[-1.8,-1.5],[1,1]],.5),stroke([[1.8,-1.5],[-1,1]],.5),disk(.7,0,4)]);
        const waves=[];for(const r of [2.2,3.8,5.4])for(const sign of [-1,1])waves.push(stroke(Array.from({length:24},(_,i)=>{const t=-.72+1.44*i/23;return [sign*r*Math.cos(t),3.1+r*Math.sin(t)];}),.65));
        return [tr(scale(mast,s),x,y),tr(scale(union(waves),s),x,y)];
      };
      // Flatten the bundled font's Bezier contours to polygons, then preserve holes with EvenOdd.
      const path={commands:[]};let pen=0,previous=null;
      for(const char of p.callsign){const glyph=font.charToGlyph(char);if(previous)pen+=font.getKerningValue(previous,glyph)*100/font.unitsPerEm;path.commands.push(...glyph.getPath(pen,0,100).commands);pen+=glyph.advanceWidth*100/font.unitsPerEm;previous=glyph;}
      const contours=[];let current=[],last=[0,0];
      for(const cmd of path.commands){
        if(cmd.type==='M'){if(current.length)contours.push(current);current=[[cmd.x,-cmd.y]];last=[cmd.x,cmd.y];}
        else if(cmd.type==='L'){current.push([cmd.x,-cmd.y]);last=[cmd.x,cmd.y];}
        else if(cmd.type==='Q'||cmd.type==='C'){const start=last;for(let i=1;i<=16;i++){const t=i/16,u=1-t;let x,y;if(cmd.type==='Q'){x=u*u*start[0]+2*u*t*cmd.x1+t*t*cmd.x;y=u*u*start[1]+2*u*t*cmd.y1+t*t*cmd.y;}else{x=u**3*start[0]+3*u*u*t*cmd.x1+3*u*t*t*cmd.x2+t**3*cmd.x;y=u**3*start[1]+3*u*u*t*cmd.y1+3*u*t*t*cmd.y2+t**3*cmd.y;}current.push([x,-y]);}last=[cmd.x,cmd.y];}
        else if(cmd.type==='Z'){if(current.length)contours.push(current);current=[];}
      }
      if(current.length)contours.push(current);const xs=contours.flat().map(v=>v[0]),ys=contours.flat().map(v=>v[1]);
      const x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),factor=Math.min(35.5/(x1-x0),7.3/(y1-y0));
      const text=tr(scale(k(new C(contours,'EvenOdd')),factor),-(x0+x1)/2*factor,.65-(y0+y1)/2*factor);
      const [mast,waves]=radio(0,12.2,1.04),globe=[];
      for(const rx of [8.5,5.4])globe.push(stroke(Array.from({length:60},(_,i)=>{const t=Math.PI*i/59;return [rx*Math.cos(t),-18+6*Math.sin(t)];}),.55));
      globe.push(stroke([[-8.5,-18],[8.5,-18]],.55),stroke([[0,-18],[0,-12]],.55));for(const yy of [-16,-14]){const h=8.5*Math.sqrt(1-((yy+18)/6)**2);globe.push(stroke([[-h,yy],[h,yy]],.5));}
      const signal=stroke([[-13.5,-7.5],[-3.2,-7.5],[-2.5,-6.7],[-1.6,-8.8],[-.3,-5.5],[.9,-9.2],[2.1,-6.8],[2.9,-7.5],[13.5,-7.5]],.65);
      const fw=union([whiteRim,text,mast,...globe]),fo=sub(union([orangeRim,ring(22.65,.65),waves,signal]),fw),fb=sub(circle,union([fw,fo]));
      const pitch=32/(qr.n+8),squares=[];for(let r=0;r<qr.n;r++)for(let c=0;c<qr.n;c++)if(qr.matrix[r][c])squares.push(rect((c-qr.n/2)*pitch,(qr.n/2-r-1)*pitch,(c+1-qr.n/2)*pitch,(qr.n/2-r)*pitch));
      const raw=union(squares),blackQR=k(k(raw.offset(-.02,'Miter')).offset(.02,'Round',2,16));
      const quiet=rect(-16,-16,16,16),[m1,w1]=radio(-19.6,-1,.57),[m2,w2]=radio(19.6,-1,.57);
      const bw=union([sub(quiet,blackQR),whiteRim,ring(23.15,.5),m1,m2]),bo=sub(union([orangeRim,w1,w2]),bw),bb=sub(circle,union([bw,bo]));
      const front=[fb,fw,fo],back=[bb,bw,bo],core=[sub(circle,union([orangeRim,whiteRim])),whiteRim,orangeRim],upper=[sub(core[0],quiet),union([whiteRim,quiet]),orangeRim];
      const xy=p.diameter/50,T=p.thickness;
      // Integer Z construction prevents floating-point gaps between layer bands.
      // One internal Z unit is 0.1 mm; final export scales Z back to millimetres.
      const extr=(shape,z,h)=>k(k(shape.extrude(Math.round(h*10))).translate([0,0,Math.round(z*10)]));
      const meshes=[],volumes=[];
      for(let i=0;i<3;i++){
        const joined=k(M.union([extr(k(front[i].mirror([1,0])),0,.6),extr(back[i],T-.6,.6),extr(core[i],.6,T-1.8),extr(upper[i],T-1.2,.6)]));
        const solid=k(k(joined.scale([xy,xy,.1])).setTolerance(.000005));
        if(solid.status()!=='NoError')throw Error('Mesh validation failed: '+solid.status());
        const mesh=solid.getMesh();meshes.push({positions:new Float32Array(mesh.vertProperties),triangles:new Uint32Array(mesh.triVerts),stride:mesh.numProp});volumes.push(solid.volume());
      }
      const expected=circle.area()*T*xy*xy;
      if(Math.abs(volumes.reduce((a,b)=>a+b,0)-expected)>expected*.0001)throw Error('Colour volumes do not cover the chip correctly.');
      return {params:p,qr,front:front.map(s=>scale(s,xy).toPolygons()),back:back.map(s=>scale(s,xy).toPolygons()),meshes,volumes};
    }finally{for(const item of pool.reverse())if(!item.isDeleted())item.delete();}
  };
}
export function stl(mesh){
  const out=new Uint8Array(84+mesh.triangles.length/3*50),v=new DataView(out.buffer);v.setUint32(80,mesh.triangles.length/3,true);
  for(let f=0;f<mesh.triangles.length/3;f++){
    const points=[0,1,2].map(j=>Array.from(mesh.positions.slice(mesh.triangles[f*3+j]*mesh.stride,mesh.triangles[f*3+j]*mesh.stride+3))),[a,b,c]=points;
    const u=b.map((x,i)=>x-a[i]),w=c.map((x,i)=>x-a[i]),normal=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]],len=Math.hypot(...normal)||1;
    [...normal.map(x=>x/len),...points.flat()].forEach((x,j)=>v.setFloat32(84+f*50+j*4,x,true));
  }return out;
}
const xml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
export function threeMF(result){
  const {params:p,meshes}=result,names=['BODY_DARK','FIELD_LIGHT','ACCENT'];
  let model=`<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><metadata name="BambuStudio:3mfVersion">1</metadata><resources><basematerials id="10">${names.map((n,i)=>`<base name="${n}" displaycolor="${p.colors[i]}FF"/>`).join('')}</basematerials>`;
  meshes.forEach((m,i)=>{model+=`<object id="${i+1}" type="model" name="${names[i]}" pid="10" pindex="${i}"><mesh><vertices>`;for(let j=0;j<m.positions.length;j+=m.stride)model+=`<vertex x="${m.positions[j]}" y="${m.positions[j+1]}" z="${m.positions[j+2]}"/>`;model+='</vertices><triangles>';for(let j=0;j<m.triangles.length;j+=3)model+=`<triangle v1="${m.triangles[j]}" v2="${m.triangles[j+1]}" v3="${m.triangles[j+2]}"/>`;model+='</triangles></mesh></object>';});
  model+=`<object id="4" type="model" name="${xml(p.callsign)}"><components>${meshes.map((_,i)=>`<component objectid="${i+1}"/>`).join('')}</components></object></resources><build><item objectid="4" transform="1 0 0 0 1 0 0 0 1 110 110 0"/></build></model>`;
  const config=`<config><object id="4"><metadata key="name" value="${xml(p.callsign)}"/>${names.map((n,i)=>`<part id="${i+1}" subtype="normal_part"><metadata key="name" value="${n}"/><metadata key="extruder" value="${i+1}"/></part>`).join('')}</object></config>`;
  return zipSync({'[Content_Types].xml':strToU8('<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/><Default Extension="config" ContentType="application/octet-stream"/></Types>'),'_rels/.rels':strToU8('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'),'3D/3dmodel.model':strToU8(model),'Metadata/model_settings.config':strToU8(config),'Metadata/project_settings.config':strToU8(JSON.stringify({filament_colour:p.colors}))});
}
export function bundle(result){
  const c=result.params.callsign.replace(/\//g,'-'),files={};
  result.meshes.forEach((m,i)=>files[`${c}_${['BODY_DARK','FIELD_LIGHT','ACCENT'][i]}.stl`]=stl(m));
  files[`${c}.3mf`]=threeMF(result);files['QR-content.txt']=strToU8(result.qr.text);files['settings.json']=strToU8(JSON.stringify(result.params,null,2));
  files['PRINT-README.txt']=strToU8(`Callsign Chip Builder\nSize: ${result.params.diameter} x ${result.params.thickness} mm\nQR: ${result.qr.n} x ${result.qr.n}; module ${result.qr.pitch.toFixed(4)} mm; ECC ${result.params.ecc}.\nPrint QR up, front on bed. All surfaces flush. No flipping or supports.\nUse your own printer profile. Three parts, filament slots 1/2/3.\nImport STL files together as ONE object with multiple parts.\nTry first layer 0.2 mm, then 0.1 mm. Ensure colour changes are properly purged.\nA digital QR and manifold geometry do not guarantee physical scanning. Test-print and scan before making a batch.\nThe package includes your entered contact information. Share it only if intended.\n`);
  return zipSync(files);
}
