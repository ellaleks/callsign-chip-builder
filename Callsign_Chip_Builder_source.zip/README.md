# Callsign Chip Builder

A browser-local customizer for a flat, double-sided amateur-radio contact chip. Enter a callsign and contact details, inspect both faces, and download three STL colour parts and an assembled 3MF.

**Prototype v0.1.** Mesh generation and digital QR decoding have been tested. Physical prints and printed QR scanning have not been validated. Check a sample before sharing claims about print quality or scan reliability.

## Run locally

Requires a recent browser with WebAssembly and module Web Workers. Serve this folder over HTTP, not `file://`:

```sh
python -m http.server 8765 --bind 127.0.0.1
```

Open `http://127.0.0.1:8765`. No npm install or build is needed. JavaScript, WASM and the font are vendored. After the local assets load, all contact and geometry processing stays in the browser. No analytics, upload endpoint, accounts or external runtime requests are included. Generated downloads contain the entered contact information; do not accidentally publish them.

## Publish on GitHub Pages

Suggested repository: `ellaleks/callsign-chip-builder`. This is a suggested destination, not a claim that the repository exists or has been published.

1. Create a public repository named `callsign-chip-builder` under your account.
2. Upload these files, retaining the `vendor`, `tests` and `.github/workflows` folders and `.nojekyll` file. Do not upload your private contact exports or other workspace files.
3. Use the `main` branch. In **Settings → Pages**, set the source to **GitHub Actions**.
4. Run the included **Check and deploy GitHub Pages** workflow, or push a commit to `main`. It tests the geometry and publishes the static site.
5. Link the successful Pages URL from the repository and Printables listing. Verify the deployed site can generate and download files before announcing it.

GitHub's hosting instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Controls and output

- Callsign: 3–12 ASCII letters, digits, `/` and `-`. The lettering fits the available width; a long callsign produces smaller strokes.
- Contacts: Unicode first name, last name, address, phone and email. Optional fields are omitted. Sample defaults do not contain the creator's personal contact data.
- Plain-text QR for fewer cells; vCard 3.0 for compatible contact-saving scanners. vCard behaviour depends on the phone/scanner; saving is not automatic or guaranteed.
- ECC L or M, diameter 40–90 mm, thickness 2.4–5 mm. Nozzle selection changes the printability warning, not the geometry.
- Three user-selected colours. A dark body and light QR field are enforced for contrast; physical filament appearance can differ from screen colours.
- Black/dark main body, coloured rim inserts through the full thickness, localized light backing below the QR.
- All face details are flush. No raised text or raised QR modules.
- ZIP: three binary STL files, multipart 3MF, contact payload, settings and printing notes. STL files have no built-in colour; the names indicate colour roles.

## QR dimensions

The full QR square, including a four-module quiet zone on each side, uses 64% of the chip diameter. For QR side `N`, module pitch is `diameter × 0.64 / (N + 8)`. The UI shows the actual pitch, byte count, version and a size suggestion based on two nozzle diameters per module. That suggestion is a conservative geometric screen, not a printing standard or a scan guarantee.

The QR is generated from the complete payload. It is never an image texture or decorative QR. Its actual black/white regions become solid geometry. Convex black module corners have a 0.02 mm radius on a 50 mm chip to avoid diagonal modules sharing a zero-thickness edge.

## Slicing

Use your own verified printer profile. Import the 3MF as a model; expand the one object and assign the three parts to dark/light/accent filaments. Or import all three STL files together as one object with multiple parts. Keep their shared coordinates; do not lay each part separately on the bed.

Print QR up and callsign face down. Try first layer 0.20 mm and subsequent layers 0.10 mm. No flipping, assembly, or supports. Surface colour depths are 0.6 mm; the white backing below the entire QR field is 1.2 mm. Thickness should align with the chosen layer height. Use opaque light filament and suitable purge settings for dark-to-light changes. Inspect isolated QR cells and white gaps in the sliced preview. Print and scan a sample under diffuse light with more than one phone before making a batch.

## Development and verification

```sh
node tests/smoke.mjs
```

Node 22 or newer; no package installation needed. The test generates four cases, including vCard, UTF-8 contact names, portable callsigns, the minimum diameter, and different thicknesses. It validates input rejection, native manifold status, bounds, volume coverage, and binary export structure. `VALIDATION.json` records additional independent Python/OpenCV checks of exported STL watertightness, colour intersections and exact QR payload decoding from face contours. These are digital checks, not physical tests.

In three tested cases OpenCV decoded the entire back-face image. In the 40 mm / QR-version-1 case it decoded the isolated QR field but did not detect the code in the full decorated face. This detection limitation is retained in the validation report. Scanner behaviour can differ; test the physical result on your intended phones. Thickness is supported in 0.1 mm increments; internal geometry uses integer Z bands to avoid numerical layer seams.

Architecture: `engine.mjs` is the shared geometry/export module; `worker.mjs` runs it off the UI thread; `app.mjs` manages the form, true geometry previews and downloads. No server is needed in production beyond static file hosting. Assets use relative paths, so a GitHub Pages project subdirectory works.

## Licensing

Original application code is offered under MIT. Bundled libraries retain their upstream licenses; see `THIRD_PARTY.md` and `vendor/`. Contact information belongs to the person entering it. Choose an appropriate license and description for models you publish; this repository does not grant rights to somebody else's contact data, trademarks or callsigns.

## Printables

Use `printables/LISTING.md` as the prepared listing text. Upload the sanitized sample models and preview, then link to the deployed customizer. The supported distribution design is an external browser customizer linked from the model listing; no claim is made that Printables hosts or executes this JavaScript application.
