import init from './vendor/manifold.js';
import * as opentype from './vendor/opentype.mjs';
import {makeEngine} from './engine.mjs';
let build;
try{
  const mod=await init();mod.setup();
  const font=opentype.parse(await (await fetch('./vendor/DejaVuSans-BoldOblique.ttf')).arrayBuffer());
  build=makeEngine(mod,font);postMessage({ready:true});
}catch(e){postMessage({fatal:String(e.message||e)});}
onmessage=e=>{const {id,params}=e.data;try{postMessage({id,result:build(params)});}catch(error){postMessage({id,error:String(error.message||error)});}};
