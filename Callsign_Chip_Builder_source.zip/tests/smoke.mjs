import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import init from '../vendor/manifold.js';
import * as opentype from '../vendor/opentype.mjs';
import {makeEngine,DEFAULTS,validate,stl,threeMF,bundle} from '../engine.mjs';
process.on('uncaughtException',e=>{console.error(e.stack);process.exit(1);});
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const bytes=await fs.readFile(path.join(root,'vendor/DejaVuSans-BoldOblique.ttf'));
const font=opentype.parse(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
const mod=await init();mod.setup();const build=makeEngine(mod,font);
const output=process.argv.find(x=>x.startsWith('--output='))?.slice(9);
const cases=[
  {...DEFAULTS,email:'operator@example.com'},
  {...DEFAULTS,callsign:'PA0TEST/P',firstName:'Test',lastName:'Operator',address:'Example Street 1, Sampletown',email:'operator@example.com',phone:'+12025550123',format:'vcard',diameter:68},
  {...DEFAULTS,callsign:'F4TEST/MM',firstName:'Тест',lastName:'Оператор',format:'vcard',thickness:2.4,ecc:'M'},
  {...DEFAULTS,callsign:'123456789012',diameter:40,thickness:5},
];
for(const bad of [{diameter:0},{callsign:'<script>'},{thickness:1},{phone:'hello\nBEGIN:VCARD'},{colors:['#ffffff','#000000','#ffffff']}])assert.throws(()=>validate({...DEFAULTS,...bad}));
for(let index=0;index<cases.length;index++){
  const result=build(cases[index]);assert.equal(result.meshes.length,3);assert.ok(result.volumes.every(v=>v>0));
  let min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
  for(const mesh of result.meshes){const data=stl(mesh);assert.equal(new DataView(data.buffer).getUint32(80,true),mesh.triangles.length/3);for(let i=0;i<mesh.positions.length;i+=mesh.stride)for(let a=0;a<3;a++){min[a]=Math.min(min[a],mesh.positions[i+a]);max[a]=Math.max(max[a],mesh.positions[i+a]);}}
  for(let a=0;a<2;a++)assert.ok(Math.abs(max[a]-min[a]-cases[index].diameter)<.001);assert.ok(Math.abs(min[2])<1e-5);assert.ok(Math.abs(max[2]-cases[index].thickness)<1e-5);
  assert.ok(threeMF(result).length>1000);assert.ok(bundle(result).length>1000);
  if(output){const dir=path.join(output,'case-'+index);await fs.mkdir(dir,{recursive:true});for(let i=0;i<3;i++)await fs.writeFile(path.join(dir,['DARK','LIGHT','ACCENT'][i]+'.stl'),stl(result.meshes[i]));await fs.writeFile(path.join(dir,'chip.3mf'),threeMF(result));await fs.writeFile(path.join(dir,'result.json'),JSON.stringify({params:result.params,qr:result.qr,back:result.back,front:result.front,volumes:result.volumes}));}
  console.log(`PASS ${cases[index].callsign} ${cases[index].format} ${cases[index].diameter}x${cases[index].thickness} mm, QR v${result.qr.version}, module ${result.qr.pitch.toFixed(3)} mm`);
}
