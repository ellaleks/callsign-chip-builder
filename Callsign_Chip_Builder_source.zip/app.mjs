import {bundle,threeMF,validate,qrInfo} from './engine.mjs';
const $=id=>document.getElementById(id),form=$('controls'),worker=new Worker('./worker.mjs',{type:'module'});
let ready=false,busy=false,next=null,id=0,current=null,latestId=0,revision=0,runningRevision=-1;
function params(){return {...Object.fromEntries(new FormData(form)),colors:[$('dark').value,$('light').value,$('accent').value]};}
function status(s){$('status').textContent=s;}
function lock(){for(const key of ['download','threeMF'])$(key).disabled=true;}
function submit(){lock();try{const p=validate(params());qrInfo(p);next={params:p,revision};process();}catch(e){next=null;status(e.message);}}
function process(){if(!ready||busy||!next)return;busy=true;const p=next.params;runningRevision=next.revision;next=null;latestId=++id;status('Building and checking three colour meshes…');worker.postMessage({id,params:p});}
function render(svg,contours,colors,diameter){svg.replaceChildren();const ns='http://www.w3.org/2000/svg';svg.setAttribute('viewBox',`${-diameter*.56} ${-diameter*.56} ${diameter*1.12} ${diameter*1.12}`);contours.forEach((list,i)=>{const path=document.createElementNS(ns,'path');path.setAttribute('d',list.map(poly=>'M'+poly.map(([x,y])=>`${x.toFixed(4)},${(-y).toFixed(4)}`).join('L')+'Z').join(''));path.setAttribute('fill',colors[i]);path.setAttribute('fill-rule','evenodd');svg.append(path);});}
worker.onmessage=e=>{
  if(e.data.ready){ready=true;submit();return;}if(e.data.fatal){status('Could not load the engine. Serve this folder over HTTP, then reload. '+e.data.fatal);return;}
  busy=false;if(next){process();return;}if(e.data.id!==latestId)return;
  if(runningRevision!==revision){status('Details changed — update the chip to refresh the files.');lock();return;}
  if(e.data.error){status(e.data.error);return;}current=e.data.result;
  const {params:p,qr}=current;render($('front'),current.front,p.colors,p.diameter);render($('back'),current.back,p.colors,p.diameter);
  $('size-label').textContent=`Ø${p.diameter} × ${p.thickness} mm`;$('module-size').replaceChildren(document.createTextNode(qr.pitch.toFixed(3)+' '));const small=document.createElement('small');small.textContent='mm / cell';$('module-size').append(small);
  $('qr-details').textContent=`Version ${qr.version} · ${qr.n} × ${qr.n} cells · ECC ${p.ecc}\n${qr.bytes} bytes · quiet zone ${qr.quiet.toFixed(2)} mm`;$('qr-details').style.whiteSpace='pre-line';$('payload').textContent=qr.text;
  const dense=qr.pitch<p.nozzle*2;const warn=$('print-warning');warn.classList.toggle('dense',dense);warn.textContent=(dense?`Fine detail for your ${p.nozzle} mm nozzle. For about two nozzle diameters per cell, use Ø${qr.recommendedDiameter} mm or reduce QR content. `:'Cell size has more room for the selected nozzle. ')+ 'Physical scanning is unverified: print one sample and test it.';
  $('format-hint').textContent=p.format==='vcard'?'Compatible scanners can offer to save the contact. Behaviour depends on your phone and scanner.':'Text shows the details. Choose Contact card to let compatible scanners offer to save a contact.';
  status('Three solid colour parts checked. Ready to export.');for(const key of ['download','threeMF'])$(key).disabled=false;
};
worker.onerror=e=>{busy=false;status('Geometry engine error: '+e.message);lock();};
form.addEventListener('submit',e=>{e.preventDefault();submit();});
form.addEventListener('input',()=>{revision++;lock();status('Details changed — update the chip to refresh the files.');});
function save(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}
$('download').onclick=()=>{if(current)save(bundle(current),current.params.callsign.replace(/\//g,'-')+'_print-kit.zip','application/zip');};
$('threeMF').onclick=()=>{if(current)save(threeMF(current),current.params.callsign.replace(/\//g,'-')+'.3mf','model/3mf');};
