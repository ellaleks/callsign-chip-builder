# Callsign Contact Chip — Browser Customizer, Flat 3-Colour STL + 3MF

Create a personal amateur-radio contact chip with your own callsign and QR contact details. The chip has a dark body, through-thickness accent inserts, a radio antenna and globe on the front, and a real contact QR on the back. All face details are flush.

## Customize your own

Open the customizer using the website link in this listing. Enter your callsign and contact details, choose the diameter and colours, update the preview, and download your print kit. Contact data is processed locally in the browser.

The customizer supports plain text and vCard 3.0. Compatible QR scanners can offer to save a vCard contact; support varies by phone. The UI displays the actual QR module size and warns when the code is fine for your selected nozzle.

## Files

- A sanitized N0CALL sample chip, with fictional demonstration information only.
- Three STL colour parts and one multipart 3MF per sample.
- Open-source browser customizer and printing instructions in the linked GitHub repository.

The generator runs on an external website linked from this model listing. The listing itself does not execute the customizer.

## Printing

- Default size: diameter 50 mm, thickness 3.5 mm. Customizer range: 40–90 mm diameter, 2.4–5 mm thickness.
- Three opaque filament colours: dark body, light QR field, accent.
- QR up, callsign face on the bed. No supports, flipping or gluing.
- Start with a 0.20 mm first layer and 0.10 mm subsequent layers. Use your printer's established multi-colour and purge settings.
- Import the STL files together as a single object with multiple parts, or use the assembled 3MF. Assign the three filament slots.
- Inspect the sliced QR and test a printed sample before making a batch.

## Validation status

Digital geometry and exact QR decoding have been tested across multiple parameter sets. Physical printing and printed QR scanning are not yet validated. Displayed module size is not a promise of scan reliability.

## Before publishing this listing

Replace this checklist with the actual deployed customizer URL and repository URL. Choose a model license, add a real test-print photo when available, and describe any observed print settings or limitations. Do not upload private contact exports. The suggested owner profile is https://www.printables.com/@AlexEll_1847124 .
